package co.iampro.mssinfotech.com.iampro.events;

public class NewLoginEvent {
  public final boolean isLoggedIn;

  public NewLoginEvent(boolean isLoggedIn) {
    this.isLoggedIn = isLoggedIn;
  }
}
