package co.iampro.mssinfotech.com.iampro.dialogs;

import android.databinding.DataBindingUtil;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.support.v4.graphics.ColorUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import co.iampro.mssinfotech.com.iampro.R;
import co.iampro.mssinfotech.com.iampro.databinding.DialogWriteReviewBinding;

public class WriteCommentDialog extends DialogFragment {

  DialogWriteReviewBinding binding;

  @Nullable
  @Override
  public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
      @Nullable Bundle savedInstanceState) {

    binding = DataBindingUtil.inflate(inflater, R.layout.dialog_write_review, container, true);
    getDialog().getWindow().requestFeature(Window.FEATURE_NO_TITLE);

    int accentColorDark = getResources().getColor(R.color.colorAccentDark);
    getDialog().getWindow().setBackgroundDrawable(new ColorDrawable(ColorUtils.setAlphaComponent(accentColorDark, 150)));

    return binding.getRoot();
  }

  @Override
  public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
    super.onViewCreated(view, savedInstanceState);

    binding.ibtnClose.setOnClickListener(v -> {
      dismiss();
    });

    binding.btnSend.setOnClickListener(v -> {
      if (validate()) {

      }
    });
  }

  @Override
  public void onStart() {
    super.onStart();

    getDialog().getWindow().setWindowAnimations(R.style.DialogFadeAnimation);
  }

  private boolean validate() {
    boolean flag = true;

    final String comment = binding.etComment.getText().toString();
    if (comment.isEmpty()) {
      flag = false;
      if (!binding.tilComment.isErrorEnabled()) binding.tilComment.setErrorEnabled(true);
      binding.tilComment.setError("Comment Required");
    } else {
      if (binding.tilComment.isErrorEnabled()) binding.tilComment.setErrorEnabled(false);
    }

    return flag;
  }
}
