package co.iampro.mssinfotech.com.iampro.utils;

public interface LoginPreferencesConstants {
  String PREF_NAME = "login_preference";

  String KEY_USERNAME = "key_username";
  String KEY_PASSWORD = "key_password";

}
