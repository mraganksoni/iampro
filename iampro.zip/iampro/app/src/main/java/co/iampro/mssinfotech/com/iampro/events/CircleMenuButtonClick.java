package co.iampro.mssinfotech.com.iampro.events;

public class CircleMenuButtonClick {
    public final String tag;

    public CircleMenuButtonClick(String tag) {
        this.tag = tag;
    }
}
