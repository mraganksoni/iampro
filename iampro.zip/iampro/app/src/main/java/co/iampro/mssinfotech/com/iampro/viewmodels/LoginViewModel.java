package co.iampro.mssinfotech.com.iampro.viewmodels;

import android.annotation.SuppressLint;
import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MutableLiveData;
import android.content.SharedPreferences;
import android.preference.Preference;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.util.Log;
import co.iampro.mssinfotech.com.iampro.models.CurrentUser;
import co.iampro.mssinfotech.com.iampro.utils.VolleyUtil;
import com.android.volley.Request.Method;
import com.android.volley.toolbox.JsonObjectRequest;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import io.reactivex.Single;
import io.reactivex.schedulers.Schedulers;
import org.json.JSONException;
import org.json.JSONObject;

public class LoginViewModel extends AndroidViewModel {
  /* ******************************************
   * Constants
   ****************************************** */
  private static final String TAG = "LoginViewModel";
  public static final String PREF_KEY_USER_INFO = "user_info";

  /* ******************************************
   * Mutable Live Data references
   ****************************************** */
  private final MutableLiveData<Boolean> loginStatus = new MutableLiveData<>();


  public LoginViewModel(@NonNull Application application) {
    super(application);
  }

  @SuppressLint("CheckResult")
  public void startLoginProcess(String username, String password) {
    final String url =
        String.format(
            "http://www.iampro.co/ajax/signup.php?type=login&username=%s&pass=%s",
            username, password);
    final JsonObjectRequest request =
        new JsonObjectRequest(
            Method.GET,
            url,
            null,
            (JSONObject response) -> {
              try {
                final String status = response.getString("status");
                if (status.equalsIgnoreCase("error")) {
                  loginStatus.setValue(false);
                } else if (status.equalsIgnoreCase("success")) {
                  SharedPreferences defaultSP = PreferenceManager.getDefaultSharedPreferences(getApplication());
                  defaultSP.edit().putString(PREF_KEY_USER_INFO, response.toString()).commit();
                  loginStatus.setValue(true);
                }
              } catch (JSONException e) {
                e.printStackTrace();
              }
            },
            error -> {
              Log.e(TAG, "startLoginProcess: a", error.getCause());
            });
    VolleyUtil.getInstance(getApplication()).addRequest(request);
  }

  public LiveData<Boolean> getLoginStatus() {
    return loginStatus;
  }
}
